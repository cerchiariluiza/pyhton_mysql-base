
create table cadastro (
 nomeCliente varchar(50),
    SobrenomeCliente varchar(100),
    sexo char (1));