<?php 
$n = $_POST["nome"];
echo $n;
echo 'executou o programa.';
?>