<?php
echo $_GET['palavra'];
?>