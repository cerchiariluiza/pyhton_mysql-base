<html>
<body>
	<form action="teste.php" method="get">
		<input type="text" name="palavra">
		<input type="submit" name="" value="testar">
	</form>
</body>

</html>