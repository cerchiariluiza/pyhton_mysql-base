<form action="resposta.php" method="post">
	Seu nome: <input type="text" name="nome">
	<input type="submit" name="">
</form>