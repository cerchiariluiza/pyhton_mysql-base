use mineracao;
 /*----------------------------------------------------------------*/
                          /*DELETAR*/
  /*----------------------------------------------------------------*/
create table apagar_um_dado (
 nome_cliente varchar(15),
 idade int);
 insert into apagar_um_dado values('Julio', 18),('Daniel', 20);
 delete from apagar_um_dado where nome_cliente='Julio';
 select * from apagar_um_dado;
 /*----------------------------------------------------------------*/
                          /*ATUALIZAR*/
  /*----------------------------------------------------------------*/
 create table atualizar_dado (
 nome_cliente varchar(15),
 idade int);
 insert into atualizar_dado values('Julio', 18),('Daniel', 20);
update apagar_um_dado set idade = 24 where nome_cliente='Daniel';
 select * from apagar_um_dado;
 /*----------------------------------------------------------------*/
                          /*CASCADE*/
  /*----------------------------------------------------------------*/

CREATE TABLE cinemas (
numero_cinema INT NOT NULL,
nome_cinema VARCHAR (30) NOT NULL,
PRIMARY KEY (numero_cinema)
) ENGINE=INNODB;

CREATE TABLE filmes (
numero_cinema INT, 
numero_filme INT,
nome_filme varchar(30),
FOREIGN KEY (numero_filme) REFERENCES cinemas(numero_cinema)
ON DELETE CASCADE
) ENGINE=INNODB;

insert into cinemas value (1, "Unibanco"),(2, "Shopping Sul");
insert into filmes value (1,1, "Orgulho e preconceito"),(1,2, "Invictus");

select * from filmes;
insert into filmes value (2,3, "Vencendo o impossivel"),(2,4, "Lago");

delete from cinemas where numero_cinema = 1;
select * from filmes;

 