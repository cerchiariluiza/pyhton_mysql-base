<!DOCTYPE html>
<html lang="pt-br">

<body>
<form action="index.php" method="POST" enctype="multipart/form-data">
<input type="file" name="arquivo">
<input type="submit" value="Enviar" name="botao">
</form>
</body>
</html>
<?php 
if(isset($_POST["botao"])){if(move_uploaded_file($_FILES['arquivo']['tmp_name'],$_FILES['arquivo']['name'])){echo '<img src="'.$_FILES['arquivo']['name'].'"style="width:200px;">';}}
?>