<?php
$origem = imageCreateFromJPEG("copia.jpg");
$saida = ImageCreateTrueColor(100,75);
ImageCopyResampled($saida, $origem, 0, 0, 0, 0, 100, 75, 300, 225);
imagejpeg($saida, "mini.jpg", 100);
?>