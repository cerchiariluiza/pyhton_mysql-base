<?php
$origem = imageCreateFromJPEG("foto.jpg");
imagejpeg($origem, "copia.jpg", 100);
?>