<?php
$carro = imageCreateFromJPEG("mercedes.jpg");
$aviso = imageCreateFromJPEG("aviso.jpg");
imageCopyMerge($carro, $aviso, 0, 0, 0, 0, 400, 230, 20);
imagejpeg($carro, "mesclado.jpg", 100);
echo '<img src="mesclado.jpg">';
?>