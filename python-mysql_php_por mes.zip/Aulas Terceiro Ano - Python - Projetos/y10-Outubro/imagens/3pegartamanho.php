<html>
<head> </head>
<body>
<img src="mini.jpg">
<?php
$dadosdafoto = getimagesize("foto.jpg");
$largura = $dadosdafoto[0];
$altura = $dadosdafoto[1];
echo $largura.' x '.$altura;
?>
</body>
</html>