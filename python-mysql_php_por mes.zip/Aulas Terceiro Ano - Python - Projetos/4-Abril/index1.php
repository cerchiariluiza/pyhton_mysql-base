<!doctype html>

<html lang="pt-br">
    <head>
 
    </head>
    <body>
       <?php
       $variavel = 10;
       echo 'Mostrar $variavel <br/>';
       echo "Mostrar $variavel <br/>";
        
        $DADOS[0] = 9;
        $DADOS[1] = 8.5;
        $DADOS[2] = 10;
        
        echo "<br/>";
        echo "<br/>";
        var_dump($DADOS);
        echo "<br/>";
        echo "<br/>";
        print_r($DADOS);
        echo "<br/>";
        echo "<br/>";
        echo $DADOS[1];
       ?>
            
    </body>
</html>