<!doctype html>
<html lang="pt-br">
    <head>
 
    </head>
    <body>
       <?php
            $x = 10.5;
            var_dump($x);
            $y = "Olá planeta!";
            var_dump($y);
        
        $DADOS[0] = 9;
     
       ?>         
    </body>
</html>