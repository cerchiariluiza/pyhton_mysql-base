/* DEFAULT*/
create database aula12_03;
use aula12_03;
CREATE TABLE pessoas (
    ID int,
    utlimo_nome varchar(255),
    primeiro_nome varchar(255),
    idade int,
    cidade varchar(255) DEFAULT 'São Paulo'
); 
insert into pessoas (ID, utlimo_nome, primeiro_nome, idade) values (1, 'Farias', 'Julio', 28);
select * from pessoas;

/* not null insere mas reclama*/
CREATE TABLE pessoas2 (
    ID int,
    utlimo_nome varchar(255),
    primeiro_nome varchar(255),
    idade int,
    cidade varchar(255) NOT NULL
    );
    insert into pessoas2 (ID, utlimo_nome, primeiro_nome, idade) values (1, 'Farias', 'Julio', 28);
select * from pessoas2;

/*unique*/
CREATE TABLE pessoas3 (
    ID int NOT NULL,
    UltimoNome varchar(255) UNIQUE,
    PrimeiroNome varchar(255),
    idade int
);
insert into pessoas3 values 
		(1, 'França', 'Julio', 20),
        (2, 'Machado', 'Gabriel', 18),
        (3, 'França', 'Daniela', 20);
        
	
