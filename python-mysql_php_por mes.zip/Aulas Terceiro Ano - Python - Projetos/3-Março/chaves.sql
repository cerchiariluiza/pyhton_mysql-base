create database chave;
use chave;

CREATE TABLE Pessoas4  (
ID_Pessoa integer PRIMARY KEY AUTO_INCREMENT,
Nome varchar(255),
Cidade varchar(255)
);


CREATE TABLE Carro(
ID_Carro integer PRIMARY KEY AUTO_INCREMENT,
Nome varchar(255),
Marca varchar(255),
ID_Pessoa integer,
CONSTRAINT fk_PesCarro FOREIGN KEY (ID_Pessoa) REFERENCES Pessoas4 (ID_Pessoa)
);

insert into Pessoas4 (Nome, Cidade) values
    ('Juliana', 'SP'),
    ('Julio', 'SP'),
    ('Márcio', 'SP');
    
insert into Carro (Nome, Marca, Id_Pessoa) values
    ('Gol', 'Wolks',2 ),
    ('Palio', 'Fiat', 3);
    
    select * from Pessoas4 INNER JOIN Carro ON (Pessoas4.ID_Pessoa = Carro.ID_Pessoa);
    
    
    /*
    Chaves primárias não podem ser nulas;
Cada registro na tabela deve possuir uma, e somente uma, chave primária;
Normalmente, chaves primárias são incrementadas automaticamente pelo banco de dados, ou seja, não há necessidade de passarmos esse valor em um INSERT. Entretanto, essa é uma opção configurada na criação da base de dados que não é obrigatória. Nos casos em que ela (incremento automático) não é definida, é preciso garantir que não haverá valores repetidos nessa coluna;
São as chaves para o relacionamento entre entidades, ou tabelas, da base de dados. Assim, haverá, na tabela relacionada, uma referência a essa chave primária (que será, na tabela relacionada, a chave estrangeira)
*/