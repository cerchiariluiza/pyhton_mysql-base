package dia13;

import java.util.Scanner;

public class Leitura1 {
	public static void main(String[] args) {		
    // ler far� a leitura 
	Scanner ler = new Scanner(System.in);
	
	/// criei as vari�veis como string
	String expressao, nome, bairro, cidade;	
		
	///o programa ler� na ordem das vari�veis
	expressao = ler.nextLine();
	nome = ler.nextLine();	
	bairro = ler.nextLine();
	cidade = ler.nextLine();
	
	///o programa mostrar� na ordem abaixo
	System.out.println(expressao);
	System.out.println(nome);
	System.out.println(bairro);
	System.out.println(cidade);
	
	// fecha a vari�vel pois n�o vou precisar mais dela
	ler.close();
	
	
	
	
	
} 
}

	






