package dia13;

import java.util.Scanner;

public class Leituras3Int {
	public static void main(String[] args) {	
		
    // ler far� a leitura 
	Scanner ler2 = new Scanner(System.in);
	    
	// Quando for inteiro deve ser nextInt
	int nota = ler2.nextInt();
	// obrigado a quebrar linha ler2.nextLine(); --- O nome disso � limpeza de strem(flush)
	String nome = ler2.nextLine();
	
	System.out.println(nota);
	System.out.println(nome);
	ler2.close();	
	
	}
}