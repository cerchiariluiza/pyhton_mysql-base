package dia13;

import java.util.Scanner;

public class Leituras4Char {
	public static void main(String[] args) {	
		
		Scanner ler = new Scanner(System.in);
		char gender = ler.next().charAt(0);
		System.out.println(gender);			
		ler.close();	
	//testar digitando feminino ou masculino
	}
}