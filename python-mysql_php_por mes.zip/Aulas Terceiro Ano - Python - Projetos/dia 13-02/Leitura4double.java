package dia13;

import java.util.Scanner;

public class Leitura4double {
	public static void main(String[] args) {
		
		Scanner quebrado = new Scanner(System.in);
		
		double peso = quebrado.nextDouble();
		System.out.println(peso);
		
		quebrado.close();	}

}
