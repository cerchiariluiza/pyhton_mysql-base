package dia13;

import java.util.Scanner;

public class Leituras2int {
	public static void main(String[] args) {	
		
    // ler far� a leitura 
	Scanner ler2 = new Scanner(System.in);
    
	// Quando for inteiro deve ser nextInt
	int nota = ler2.nextInt();
	System.out.println(nota);
	ler2.close();	
	
	}
}