package dia13;

import java.util.Scanner;

public class Leituras5Fatias {
	public static void main(String[] args) {	
		
		Scanner fatias = new Scanner(System.in);
		
		String parte1 = fatias.next();
		char primeira_letra = parte1.charAt(0);
		System.out.println(primeira_letra);
			
	
	//digitar a palavra imprime a primeira letra
		// criar outra char que imprima a segunda letra
	}
}