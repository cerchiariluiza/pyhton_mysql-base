package dia13;

public class aaRevisao {
	public static void main(String[] args) {
		
		double valor1 = 10;
		double valor2 = 20;	
		
	  System.out.println(valor1);
	  System.out.println(valor2);
	  System.out.println("--------------------");
	  
	  valor1 += 2;
	  valor2 *= 3;
	  System.out.println(valor1);
	  System.out.println(valor2);

	}
	}


